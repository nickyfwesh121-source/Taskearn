window.onload = function () {
    const username = localStorage.getItem("loggedInUser");
    const userRole = localStorage.getItem("userRole");

    if (!username) {
        alert("You must log in first.");
        window.location.href = "login.html";
        return;
    }

    // Load user data
    const userData = JSON.parse(localStorage.getItem("user_" + username) || "{}");
    const balance = userData.balance || 0;
    const refBalance = userData.refBalance || 0;

    // Display user
    document.getElementById("welcomeText").innerText = "Welcome, " + username;
    document.getElementById("mainBalance").innerText = "₦" + balance;
    document.getElementById("refBalance").innerText = "₦" + refBalance;

    // SHOW ADMIN BUTTONS IF USER IS ADMIN
    if (userRole === "admin") {
        document.querySelectorAll(".adminOnly").forEach(el => {
            el.style.display = "block";
        });
    }

    loadTransactions();
};

// LOGOUT
function logout() {
    localStorage.removeItem("loggedInUser");
    localStorage.removeItem("userRole");
    window.location.href = "login.html";
}

// LOAD RECENT TRANSACTIONS
function loadTransactions() {
    const username = localStorage.getItem("loggedInUser");
    const txKey = "transactions_" + username;

    const userTransactions = JSON.parse(localStorage.getItem(txKey) || "[]");

    const container = document.getElementById("transactionsList");
    container.innerHTML = "";

    if (userTransactions.length === 0) {
        container.innerHTML = "<p style='text-align:center;color:gray;'>No recent transactions.</p>";
        return;
    }

    // Show only recent 5
    userTransactions.slice(0, 5).forEach(tx => {
        const item = document.createElement("div");

        item.style = `
            background:white;
            padding:12px;
            margin-bottom:10px;
            border-radius:10px;
            box-shadow:0px 1px 4px rgba(0,0,0,0.1);
        `;

        item.innerHTML = `
            <strong>${tx.type}</strong><br>
            <small>${tx.date}</small><br>
            <b style="color:${tx.amount > 0 ? 'green' : 'red'};">
                ${tx.amount > 0 ? '+' : ''}₦${tx.amount}
            </b>
        `;

        container.appendChild(item);
    });
}