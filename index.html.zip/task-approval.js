document.addEventListener("DOMContentLoaded", () => {
    loadApprovals();
});

function loadApprovals() {
    let list = document.getElementById("approvalList");
    let submissions = JSON.parse(localStorage.getItem("submissions") || "[]");

    let pending = submissions.filter(s => s.status === "Pending");

    if (pending.length === 0) {
        list.innerHTML = "<p>No pending submissions.</p>";
        return;
    }

    list.innerHTML = "";

    pending.forEach(sub => {
        let div = document.createElement("div");
        div.className = "submission-card";

        div.innerHTML = `
            <h3>${sub.taskTitle}</h3>

            <p><b>Submitted By:</b> ${sub.submittedBy || "Unknown User"}</p>
            <p><b>Social Username:</b> ${sub.username || "Not provided"}</p>

            <p style="font-weight:600;color:#28a745;">
                Reward: ₦${sub.reward}
            </p>

            <img src="${sub.proof}" alt="Proof">

            <div style="display:flex;justify-content:space-between;margin-top:10px;">
                <button class="action-btn approve" onclick="approveTask(${sub.id})">Approve</button>
                <button class="action-btn reject" onclick="rejectTask(${sub.id})">Reject</button>
            </div>
        `;

        list.appendChild(div);
    });
}

/* ---------------------------
   APPROVE TASK
---------------------------- */
function approveTask(id) {
    let submissions = JSON.parse(localStorage.getItem("submissions") || "[]");
    let submission = submissions.find(s => s.id === id);

    if (!submission) return;

    submission.status = "Approved";
    localStorage.setItem("submissions", JSON.stringify(submissions));

    /* ---------------------------
       UPDATE USER BALANCE
    ---------------------------- */
    let userKey = "user_" + submission.submittedBy;
    let userData = JSON.parse(localStorage.getItem(userKey) || "{}");

    if (!userData.balance) userData.balance = 0;

    userData.balance += Number(submission.reward);
    localStorage.setItem(userKey, JSON.stringify(userData));

    /* ---------------------------
       ADD APPROVED TRANSACTION
    ---------------------------- */
    let txKey = "transactions_" + submission.submittedBy;
    let txList = JSON.parse(localStorage.getItem(txKey) || "[]");

    txList.unshift({
        type: "Task Reward: " + submission.taskTitle,
        amount: submission.reward,
        date: new Date().toLocaleString(),
        status: "Approved"
    });

    localStorage.setItem(txKey, JSON.stringify(txList));

    alert("Approved! ₦" + submission.reward + " added to user's balance.");
    loadApprovals();
}

/* ---------------------------
   REJECT TASK
---------------------------- */
function rejectTask(id) {
    let submissions = JSON.parse(localStorage.getItem("submissions") || "[]");
    let submission = submissions.find(s => s.id === id);

    if (!submission) return;

    submission.status = "Rejected";
    localStorage.setItem("submissions", JSON.stringify(submissions));

    /* ---------------------------
       ADD REJECTED TRANSACTION
    ---------------------------- */
    let txKey = "transactions_" + submission.submittedBy;
    let txList = JSON.parse(localStorage.getItem(txKey) || "[]");

    txList.unshift({
        type: "Task Submission: " + submission.taskTitle,
        amount: submission.reward,
        date: new Date().toLocaleString(),
        status: "Rejected"
    });

    localStorage.setItem(txKey, JSON.stringify(txList));

    alert("Submission rejected.");
    loadApprovals();
}