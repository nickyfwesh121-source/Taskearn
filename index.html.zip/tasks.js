document.addEventListener("DOMContentLoaded", () => {
    loadTasks();
});

function loadTasks() {
    let taskList = document.getElementById("taskList");
    let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");

    let isAdmin = localStorage.getItem("userRole") === "admin";
    let username = localStorage.getItem("loggedInUser");

    if (!username) {
        alert("Error: No username found. Please log in again.");
        window.location.href = "login.html";
        return;
    }

    let completed = JSON.parse(localStorage.getItem("completedTasks") || "[]");

    // Hide tasks user already completed
    tasks = tasks.filter(t => !completed.some(c => c.username === username && c.taskId === t.id));

    if (tasks.length === 0) {
        taskList.innerHTML = "<p>No tasks available.</p>";
        return;
    }

    taskList.innerHTML = "";

    tasks.forEach(task => {
        // 🔥 FIX: Detect link correctly no matter what key was used
        let taskLink =
            task.link ||
            task.url ||
            task.taskLink ||
            task.website ||
            task.task_url ||
            task.taskUrl ||
            task.linkUrl ||
            "";

        let div = document.createElement("div");
        div.className = "task-card";

        div.innerHTML = `
            <h3 style="font-weight:700;margin-bottom:5px;">${task.title}</h3>

            <p>${task.desc}</p>

            <p style="font-weight:600">
                Slots: ${task.slots - task.taken} remaining
            </p>

            <p style="font-weight:600; color:#28a745;">
                Reward: ₦${task.reward}
            </p>

            <button onclick="openTaskLink('${taskLink}')"
                style="background:#007bff;color:#fff;padding:8px 14px;border:none;border-radius:6px;margin-bottom:12px;">
                Open Link
            </button>

            <div>
                <label><b>Upload Screenshot:</b></label>
                <input type="file" accept="image/*" id="proof-${task.id}">
            </div>

            <label><b>Social Username (optional):</b></label>
            <input type="text" id="username-${task.id}" placeholder="@yourusername"
                style="width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;">

            <button onclick="submitTask(${task.id})"
                style="width:100%;background:green;color:white;padding:10px;border:none;border-radius:6px;margin-top:10px;">
                Submit Proof
            </button>

            ${isAdmin ? `
                <button onclick="editTask(${task.id})"
                    style="width:100%;background:orange;color:white;padding:10px;border:none;border-radius:6px;margin-top:10px;">
                    EDIT TASK
                </button>

                <button onclick="deleteTask(${task.id})"
                    style="width:100%;background:red;color:white;padding:10px;border:none;border-radius:6px;margin-top:10px;">
                    DELETE TASK
                </button>
            ` : ""}
        `;

        taskList.appendChild(div);
    });
}

/* ----------------------------------------------
   OPEN TASK LINK — FIXED
------------------------------------------------ */
function openTaskLink(url) {
    if (!url || url.trim() === "") {
        alert("This task has no link.");
        return;
    }

    // Add https:// automatically
    if (!url.startsWith("http")) {
        url = "https://" + url;
    }

    window.open(url, "_blank");
}

/* ----------------------------------------------
   SUBMIT TASK
------------------------------------------------ */
function submitTask(taskId) {
    let username = localStorage.getItem("loggedInUser");
    if (!username) {
        alert("Error: Username missing. Please log in again.");
        window.location.href = "login.html";
        return;
    }

    let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
    let task = tasks.find(t => t.id === taskId);

    let proofInput = document.getElementById(`proof-${taskId}`);
    if (!proofInput.files.length) return alert("Upload screenshot proof.");

    let reader = new FileReader();
    reader.onload = function () {

        let social = document.getElementById(`username-${taskId}`).value;

        let submissions = JSON.parse(localStorage.getItem("submissions") || "[]");

        submissions.push({
            id: Date.now(),
            taskId,
            taskTitle: task.title,
            reward: Number(task.reward),
            proof: reader.result,
            username: social || "Not provided",
            submittedBy: username,
            status: "Pending"
        });

        localStorage.setItem("submissions", JSON.stringify(submissions));

        // Reduce slot and delete if exhausted
        task.taken++;
        if (task.taken >= task.slots) {
            tasks = tasks.filter(t => t.id !== taskId);
        }

        // Save completed entry
        let completed = JSON.parse(localStorage.getItem("completedTasks") || "[]");
        completed.push({ username, taskId });
        localStorage.setItem("completedTasks", JSON.stringify(completed));

        localStorage.setItem("tasks", JSON.stringify(tasks));

        // Save pending transaction
        let txKey = "transactions_" + username;
        let txList = JSON.parse(localStorage.getItem(txKey) || "[]");

        txList.unshift({
            type: "Task Submission: " + task.title,
            amount: task.reward,
            status: "Pending"
        });

        localStorage.setItem(txKey, JSON.stringify(txList));

        alert("Task submitted! Await approval.");
        loadTasks();
    };

    reader.readAsDataURL(proofInput.files[0]);
}

/* ----------------------------------------------
   DELETE TASK (ADMIN)
------------------------------------------------ */
function deleteTask(taskId) {
    let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
    tasks = tasks.filter(t => t.id !== taskId);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    alert("Task deleted.");
    loadTasks();
}

/* ----------------------------------------------
   EDIT TASK (ADMIN)
------------------------------------------------ */
function editTask(taskId) {
    let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
    let task = tasks.find(t => t.id === taskId);

    if (!task) return alert("Task not found!");

    let newTitle = prompt("Edit Title:", task.title);
    if (!newTitle) return;

    let newDesc = prompt("Edit Description:", task.desc);
    if (!newDesc) return;

    let newReward = prompt("Edit Reward:", task.reward);
    if (!newReward) return;

    let newSlots = prompt("Edit Slots:", task.slots);
    if (!newSlots) return;

    task.title = newTitle;
    task.desc = newDesc;
    task.reward = Number(newReward);
    task.slots = Number(newSlots);

    localStorage.setItem("tasks", JSON.stringify(tasks));

    alert("Task updated successfully!");
    loadTasks();
}