// GENERATE UNIQUE REFERRAL CODE
function generateReferralCode() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code = "TW";
    for (let i = 0; i < 6; i++) {
        code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
}

// DETECT REFERRAL FROM URL
window.onload = function () {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get("ref");

    if (ref) {
        const referralInput = document.getElementById("referral");
        if (referralInput) {
            referralInput.value = ref;
        }
    }
};

// REGISTER USER
function registerUser() {
    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const referral = document.getElementById("referral").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (!username || !email || !password || !confirmPassword) {
        alert("Please fill all required fields.");
        return;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
    }

    if (localStorage.getItem("user_" + username)) {
        alert("Username already taken!");
        return;
    }

    // Generate referral code for NEW USER
    const newReferralCode = generateReferralCode();

    let userData = {
        username,
        email,
        password,
        referralCode: newReferralCode,   // this user's unique code
        referredBy: referral || null,    // who referred this user
        balance: 0,                      // task balance
        refBalance: 0,                   // referral earnings
        role: "user"
    };

    // Save user
    localStorage.setItem("user_" + username, JSON.stringify(userData));

    // Give reward to referrer
    if (referral) {
        giveReferralReward(referral, username);
    }

    alert("Account created successfully!");
    window.location.href = "login.html";
}

// GIVE ₦50 TO REFERRER
function giveReferralReward(referralCode, newUser) {

    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);

        if (key.startsWith("user_")) {
            let user = JSON.parse(localStorage.getItem(key));

            if (user.referralCode === referralCode) {

                // Add ₦50 to refBalance
                user.refBalance = (user.refBalance || 0) + 50;

                // Save
                localStorage.setItem(key, JSON.stringify(user));

                // Save referred user under referrer's list
                let list = JSON.parse(localStorage.getItem("ref_list_" + user.username) || "[]");
                list.push(newUser);
                localStorage.setItem("ref_list_" + user.username, JSON.stringify(list));

                return;
            }
        }
    }
}