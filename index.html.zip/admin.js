document.addEventListener("DOMContentLoaded", loadSubmissions);

function loadSubmissions() {
    let submissions = JSON.parse(localStorage.getItem("submissions") || "[]");
    let list = document.getElementById("submissionList");

    if (submissions.length === 0) {
        list.innerHTML = "<p>No submissions found.</p>";
        return;
    }

    list.innerHTML = "";

    submissions.forEach(sub => {
        let div = document.createElement("div");
        div.style = `
            background:#fff;
            padding:15px;
            margin-bottom:15px;
            border-radius:10px;
            box-shadow:0 2px 5px rgba(0,0,0,0.1);
        `;

        div.innerHTML = `
            <h3>${sub.taskTitle}</h3>
            <p><b>User:</b> ${sub.username || "N/A"}</p>

            <img src="${sub.proof}"
                 style="width:100%; border-radius:10px; margin:10px 0;">

            <button onclick="approve(${sub.id})"
                style="background:green; color:white; padding:10px; border:none; border-radius:6px; width:48%;">
                APPROVE
            </button>

            <button onclick="decline(${sub.id})"
                style="background:red; color:white; padding:10px; border:none; border-radius:6px; width:48%; float:right;">
                DECLINE
            </button>
        `;

        list.appendChild(div);
    });
}